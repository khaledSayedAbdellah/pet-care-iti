
staticData = {
    secretKey: "kaammomogeya",
}




module.exports = staticData;